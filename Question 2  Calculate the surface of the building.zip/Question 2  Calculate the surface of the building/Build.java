
import java.util.*;

public class Build
{ 
	
	static final int M=2; 
	static final int N=2;

static int b_height(int c, int old) 
	{ 
		return Math.abs(c- old); 
	} 
	
	static int s_Area(int A[][]) 
	{   
		int ans = 0; 
	for (int i = 0; i < N; i++) 
		{ 
			for (int j = 0; j < M; j++) { 
	          int up = 0, left = 0; 
          	if (i > 0) 
					up = A[i - 1][j]; 
	       	if (j > 0) 
					left = A[i][j - 1]; 
            ans += b_height(A[i][j], up) + b_height(A[i][j], left); 
	
       		if (i == N - 1) 
					ans += A[i][j]; 
	
				if (j == M - 1) 
					ans += A[i][j]; 
			} 
		}
		ans+=N*4*2;
		return ans; 
	} 

	public static void main (String[] args) 
	{ 
		 Scanner s= new Scanner(System.in);

	        System.out.println("ENTER Number OF BUILDINGS : ");
	        int n = s.nextInt();
	        
             for (int i = 0; i < n; i++) {
	        	System.out.println("ENTER "+(i+1)+ "BUILDING COORDINATES: ");
	        	double xp= s.nextDouble(), yp = s.nextDouble();
	        	
	        }
	        double a=4.0+4.0;
	        System.out.println("ENTER COORDINATES OF POINT S:");
	        double p1 = s.nextDouble(), p2 = s.nextDouble();
	        
	       if ((s_Area(n))) 
	        { 
	            System.out.println(a); 
	        }  
	         
	        else  {
	        	 System.out.println("To Be calculated"); 
	        }
	    }
	private static boolean s_Area(int n1)
 {
		
		return true;
	}
}

	
	