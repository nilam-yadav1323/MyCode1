
import java.util.*;

public class Polygon 
{ 
    
    static int max = 10000; 
  
    static class Point
    { 
        double x; 
        double y; 
  
        public Point (double a, double b) 
        { 
            this.x = a; 
            this.y = b; 
        } 
    }; 
   
    static boolean onSegment(Point p, Point q , Point  r)  
    { 
        if (q.x <= Math.max(p.x, r.x) && 
            q.x >= Math.min(p.x, r.x) && 
            q.y <= Math.max(p.y, r.y) && 
            q.y >= Math.min(p.y, r.y)) 
        { 
            return true; 
        } 
        return false; 
    } 
   
    static int orientation(Point p, Point q, Point r)  
    { 
        double val = (q.y - p.y) * (r.x - q.x) 
                - (q.x - p.x) * (r.y - q.y); 
  
        if (val == 0)  
        { 
            return 0; 
        } 
        return (val > 0) ? 1 : 2;
    } 
  
    static boolean doIntersect(Point p1, Point q1,  
                               Point p2, Point q2)  
    { 
 
        int n1= orientation(p1, q1, p2); 
        int n2= orientation(p1, q1, q2); 
        int n3= orientation(p2, q2, p1); 
        int n4 = orientation(p2, q2, q1); 

        if (n1!= n2 && n3 != n4) 
        { 
            return true; 
        } 
  
        if (n1 == 0 && onSegment(p1, p2, q1))  
        { 
            return true; 
        } 

        if (n2 == 0 && onSegment(p1, q2, q1))  
        { 
            return true; 
        } 
        
        if (n3 == 0 && onSegment(p2, p1, q2)) 
        { 
            return true; 
        } 

        if (n4 == 0 && onSegment(p2, q1, q2)) 
        { 
             return true; 
        } 
  
    return false;
    } 
  
    static boolean isInside(Point polygon[], int n, Point p) 
    { 
        if (n < 3)  
        { 
          System .out.println ("enter valid sides");
             } 
  
        Point e = new Point(max,p.y); 
  
        int count = 0, i = 0; 
        do 
        { 
            int next = (i + 1) % n; 
  
            if (doIntersect(polygon[i], polygon[next], p, e))  
            { 
                if (orientation(polygon[i], p, polygon[next]) == 0) 
                { 
                    return onSegment(polygon[i], p, 
                                     polygon[next]); 
                } 
  
                count++; 
            } 
            i = next; 
        } while (i != 0); 
  
        return (count % 2 == 1);
    } 
  
    public static void main(String[] args)  
    { 
        
        Scanner scan = new Scanner(System.in);

        System.out.println("NUMBER OF POLYGON SIDE : ");
        int n = scan.nextInt(); 
        Point polygon1[] = new Point[n]; 
        
        for (int i = 0; i < n; i++) {
            System.out.println("ENTER Point  " + (i+1));
            double xp= scan.nextDouble(), yp = scan.nextDouble();
            polygon1[i] = new Point(xp, yp);
        }
        
        System.out.println("ENTER COORDINATE OF POINT : ");
        double p1 = scan.nextDouble(), p2 = scan.nextDouble();
        
        Point p = new Point(p1, p2); 
        if (isInside(polygon1, n, p)) 
        { 
            System.out.println("True"); 
        }  
        else 
        { 
            System.out.println("False "); 
        } 
    } 
} 
